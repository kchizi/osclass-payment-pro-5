<?php /* My software never has bugs. It just develops random features. */ ?>

