<?php
$status = PagseguroPayment::processPayment();
echo $status;