<?php

namespace mywaypay;

class AlipayAccount extends ExternalAccount
{

}
