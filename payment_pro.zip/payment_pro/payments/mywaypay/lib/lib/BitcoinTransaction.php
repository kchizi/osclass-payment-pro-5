<?php

namespace mywaypay;

class BitcoinTransaction extends ApiResource
{

}
