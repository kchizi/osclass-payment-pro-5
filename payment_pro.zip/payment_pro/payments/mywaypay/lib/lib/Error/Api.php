<?php

namespace mywaypay\Error;

class Api extends Base
{
}
