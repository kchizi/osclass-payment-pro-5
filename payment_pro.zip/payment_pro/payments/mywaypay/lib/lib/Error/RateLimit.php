<?php

namespace mywaypay\Error;

class RateLimit extends InvalidRequest
{
}
