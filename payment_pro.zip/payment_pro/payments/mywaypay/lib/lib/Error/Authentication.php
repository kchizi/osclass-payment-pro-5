<?php

namespace mywaypay\Error;

class Authentication extends Base
{
}
