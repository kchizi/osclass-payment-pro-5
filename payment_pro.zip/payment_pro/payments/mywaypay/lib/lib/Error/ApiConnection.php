<?php

namespace mywaypay\Error;

class ApiConnection extends Base
{
}
