<?php

namespace mywaypay;

class BankAccount extends ExternalAccount
{

}
