<?php

namespace mywaypay;

class Card extends ExternalAccount
{

}
